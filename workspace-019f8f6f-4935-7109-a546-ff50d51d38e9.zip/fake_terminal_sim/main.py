#!/usr/bin/env python3
import random
import signal
import sys
import time
from datetime import datetime
from config import (
    REFRESH_INTERVAL_SECONDS,
    MIN_OPS_PER_TICK,
    MAX_OPS_PER_TICK,
    TICK_SECONDS,
    LOG_TO_FILE,
    LOG_FILE_PATH,
)

RUNNING = True
sys.stdout.reconfigure(line_buffering=True)

SCENARIOS = {
    "1": {
        "name": "API Job Monitor Demo",
        "items": ["worker-01", "worker-02", "worker-03", "gateway", "scheduler"],
        "actions": [
            "heartbeat received",
            "processed synthetic batch",
            "retried safe request",
            "cache warmed",
            "response validated",
        ],
        "unit": "jobs",
    },
    "2": {
        "name": "Token Scan Demo",
        "items": ["segment-A", "segment-B", "segment-C", "node-7", "node-9"],
        "actions": [
            "synthetic token checked",
            "mock signature verified",
            "sample payload inspected",
            "sandbox rule matched",
            "rate window updated",
        ],
        "unit": "checks",
    },
    "3": {
        "name": "Queue Worker Demo",
        "items": ["queue-alpha", "queue-beta", "queue-gamma", "queue-delta"],
        "actions": [
            "mock task dequeued",
            "safe payload transformed",
            "batch acknowledged",
            "retry bucket scanned",
            "result packaged",
        ],
        "unit": "tasks",
    },
}


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log_line(message: str) -> None:
    line = f"[{now_str()}] {message}"
    print(line)
    if LOG_TO_FILE:
        with open(LOG_FILE_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def handle_sigint(sig, frame):
    global RUNNING
    RUNNING = False
    print("\n[!] Ctrl+C received. Stopping safely...")


def show_menu() -> str:
    print("=" * 44)
    print("      Safe CLI Simulator for Linux")
    print("=" * 44)
    print("1) API Job Monitor Demo")
    print("2) Token Scan Demo")
    print("3) Queue Worker Demo")
    print("4) Exit")
    print("-" * 44)
    return input("Select option: ").strip()


def simulate_step(scenario: dict, total_ops: int) -> int:
    ops = random.randint(MIN_OPS_PER_TICK, MAX_OPS_PER_TICK)
    for _ in range(random.randint(1, 3)):
        item = random.choice(scenario["items"])
        action = random.choice(scenario["actions"])
        suffix = random.randint(10, 999)
        log_line(f"[LOG] {action} on {item} #{suffix}")
    return total_ops + ops


def run_demo(choice: str) -> None:
    scenario = SCENARIOS[choice]
    total_ops = 0
    start_time = time.time()
    last_refresh = start_time

    log_line(f"[INFO] Starting demo: {scenario['name']}")
    log_line("[INFO] Press Ctrl+C to stop.")

    while RUNNING:
        total_ops = simulate_step(scenario, total_ops)
        time.sleep(TICK_SECONDS)

        now = time.time()
        if now - last_refresh >= REFRESH_INTERVAL_SECONDS:
            elapsed = int(now - start_time)
            rate = total_ops / elapsed if elapsed > 0 else 0.0
            log_line(
                f"[STATS] elapsed={elapsed}s | simulated_{scenario['unit']}={total_ops} | rate={rate:.2f} {scenario['unit']}/s"
            )
            last_refresh = now

    elapsed = int(time.time() - start_time)
    rate = total_ops / elapsed if elapsed > 0 else 0.0
    log_line(
        f"[FINAL] demo={scenario['name']} | elapsed={elapsed}s | simulated_{scenario['unit']}={total_ops} | avg_rate={rate:.2f} {scenario['unit']}/s"
    )


def main() -> None:
    signal.signal(signal.SIGINT, handle_sigint)

    while True:
        choice = show_menu()
        if choice == "4":
            print("Bye.")
            sys.exit(0)
        if choice not in SCENARIOS:
            print("Invalid option. Try again.\n")
            continue
        run_demo(choice)
        break


if __name__ == "__main__":
    main()
