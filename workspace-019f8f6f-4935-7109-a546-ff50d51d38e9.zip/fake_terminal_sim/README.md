# Fake Terminal Simulator (Safe Demo)

یک پروژه‌ی نمایشی با پایتون برای لینوکس که یک رابط ترمینالی با منوی عددی نشان می‌دهد،
لاگ زنده تولید می‌کند، هر ۶۰ ثانیه آمار را به‌روزرسانی می‌کند و تا زمان `Ctrl+C` اجرا می‌شود.

> این پروژه صرفاً **شبیه‌ساز بی‌خطر** است و هیچ کار واقعی روی رمز، حساب، کارت، یا سرویس‌های دیگر انجام نمی‌دهد.
> برای استفاده‌های نمایشی، تمرینی، رابط کاربری CLI، یا اتصال بعدی به APIهای مجاز طراحی شده است.

## قابلیت‌ها

- منوی عددی در شروع برنامه
- شبیه‌سازی چند سناریوی بی‌خطر
- لاگ زنده در ترمینال
- شمارنده‌ی عملیات ساختگی
- گزارش هر ۶۰ ثانیه
- توقف امن با `Ctrl+C`
- ساختار آماده برای اضافه‌کردن API واقعی و مجاز در آینده

## پیش‌نیاز

- Linux
- Python 3.10+

## اجرا

```bash
git clone <YOUR_GITHUB_REPO_URL>
cd fake_terminal_sim
python3 main.py
```

## ساختار پروژه

```text
fake_terminal_sim/
├── main.py
├── config.py
├── requirements.txt
└── README.md
```

## سناریوهای فعلی

1. API Job Monitor Demo
2. Token Scan Demo
3. Queue Worker Demo
4. Exit

## اضافه کردن API واقعی در آینده

بعداً می‌توانی این بخش‌ها را پر کنی:

- `config.py` برای کلیدها و تنظیمات
- تابع `simulate_step(...)` در `main.py` برای جایگزینی منطق نمایشی با منطق مجاز واقعی
- ذخیره‌ی لاگ در فایل
- ارسال درخواست به APIهای خودت

## نمونه خروجی

```text
=== Safe CLI Simulator ===
1) API Job Monitor Demo
2) Token Scan Demo
3) Queue Worker Demo
4) Exit

Select option: 1

[INFO] Starting demo: API Job Monitor Demo
[LOG] heartbeat received from worker-02
[LOG] processed synthetic batch #14
[STATS] elapsed=60s | simulated_ops=482 | rate=8.03 ops/s
```

## انتشار روی GitHub

```bash
git init
git add .
git commit -m "Initial safe simulator"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```

## نکته

اگر خواستی، در مرحله‌ی بعدی می‌توانم این پروژه را برایت به یکی از این‌ها تبدیل کنم:

- نسخه‌ی رنگی با `rich`
- نسخه‌ی دارای لاگ فایل
- نسخه‌ی چندنخی
- نسخه‌ی متصل به API واقعی و مجاز
- نسخه‌ی دارای بنر و استایل حرفه‌ای‌تر
